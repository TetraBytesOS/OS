package escritorio;

public class Uso_Escritorio {

	public static void main(String[] args) {

		VentanaEscritorio escritorio=new  VentanaEscritorio();
		

	}

}
