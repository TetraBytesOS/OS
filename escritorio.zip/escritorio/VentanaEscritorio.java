package escritorio;

import javax.swing.JButton;
import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.IOException;
import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Random;
import java.util.Timer;
import java.util.TimerTask;

import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JPanel;

public class VentanaEscritorio extends JFrame {

	Toolkit miToolkit=Toolkit.getDefaultToolkit();
	
	public VentanaEscritorio() { //Establece las propiedades de la ventana
		setBounds(0,0,miToolkit.getScreenSize().width, miToolkit.getScreenSize().height);
		PanelEscritorio panel=new PanelEscritorio();
		add(panel);
		setVisible(true);
		setDefaultCloseOperation(EXIT_ON_CLOSE);

		// Reproducir sonido al abrir la app
		ReproductorSonido.reproducir("/escritorio/sonidos/FUCK-YOU_-Sound-Effect-_Official-Stereo_.wav");
	}
	
}

class PanelEscritorio extends JPanel implements ActionListener{ //Es el panel que coloca los botones y decora la ventana
	
	private Toolkit miToolkit=Toolkit.getDefaultToolkit();
	private int centroY= (miToolkit.getScreenSize().height/2)-20;
	private int centroX= (miToolkit.getScreenSize().width/2)-100;
	private File archivoImagenShell=new File("src/escritorio/fuck_you.png");
	private Image imagenShell;
	private JButton botonShell=new JButton("FUCK SHELL",setIconoShell());
	private File archivoImagenApp2=new File("src/escritorio/fuck_you.png");
	private Image imagenAPP2;
	private JButton botonApp2=new JButton("App2",setIcono2());

	
	public PanelEscritorio() {
		setTempo();
		ranSon();
		setLayout(null); //Esta linea es la que permite poder colocar despues el boton donde queramos
		add(botonShell);
		botonShell.addActionListener(this);
		botonShell.setBounds(10, 10, 70, 90);
		add(botonApp2);
		botonApp2.addActionListener(this);
		botonApp2.setBounds(10, 110, 70, 90);
		
	}

	
	public void setTempo() { //Cambia el color de fondo
	
	Timer miTimer=new Timer();
	TimerTask tarea=new TimerTask() {

		@Override
		public void run() {
			int miRandom=new Random().nextInt(5);
			if(miRandom==0) setBackground(Color.YELLOW);
			else if(miRandom==1) setBackground(new Color(250,110,199));
			else if(miRandom==2) setBackground(new Color(15,255,80));
			else if(miRandom==3) setBackground(Color.WHITE);
			else setBackground(new Color(74,65,42));

		}
	};
	miTimer.schedule(tarea, 500, 500);
	}

	public void ranSon(){
		Timer miTimer=new Timer();
		TimerTask task= new TimerTask() {

			@Override
			public void run() {
				String [] ranSon=new String[6];
				ranSon[0]="/escritorio/sonidos/083902_guy-screams-quotfuckquotwav-83352.wav";
				ranSon[1]="/escritorio/sonidos/eaaaaah-321241.wav";
				ranSon[2]="/escritorio/sonidos/FUCK-YOU_-Sound-Effect-_Official-Stereo_.wav";
				ranSon[3]="/escritorio/sonidos/metal-pipe-230698.wav";
				ranSon[4]="/escritorio/sonidos/shut-up-85219.wav";
				ranSon[5]="/escritorio/sonidos/screaming-46040.wav";
				String sonidoAleatorio =ranSon[new Random().nextInt(ranSon.length)];
				ReproductorSonido.reproducir(sonidoAleatorio);
			}
		};
	miTimer.schedule(task, 1000, new Random().nextInt(50000));
	}
	
	
	public void paintComponent(Graphics g) { //Pone el texto del fondo ("Fuck you")
		super.paintComponent(g);
		
		g.setColor(Color.RED);
		g.setFont(new Font("Times New Roman",Font.BOLD,30));
		g.drawString("FUCK YOU", centroX, centroY);
		
	}
	
	
	
	public ImageIcon setIconoShell() { //pone el icono de la shell
		try {
			imagenShell=ImageIO.read(archivoImagenShell);
			imagenShell=imagenShell.getScaledInstance(80, 90, Image.SCALE_SMOOTH);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			System.out.println("Imagen no encontrada");
		}
		ImageIcon iconoShell=new ImageIcon(imagenShell);
		return iconoShell;
	}
	
	public ImageIcon setIcono2() { //Pone el icono de la segunda aplicacion
		try {
			imagenAPP2=ImageIO.read(archivoImagenApp2);
			imagenAPP2=imagenAPP2.getScaledInstance(80, 90, Image.SCALE_SMOOTH);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			System.out.println("Imagen no encontrada");
		}
		ImageIcon iconoAPP2=new ImageIcon(imagenAPP2);
		return iconoAPP2;
	}


	private ToggleCapsLock capsLockInstance = new ToggleCapsLock();
	private boolean isCapsLockRunning = false; // Para controlar si ToggleCapsLock está en ejecución



	@Override
	public void actionPerformed(ActionEvent e) { //Este es el metodo con el que teneis que trabajar
		Object botonPulsado=e.getSource();
		if (botonPulsado == botonShell) {
			setBackground(Color.BLACK);
			ReproductorSonido.reproducir("/escritorio/sonidos/eaaaaah-321241.wav");

			try {
				// Comando: ejecuta el script dentro de Ubuntu WSL y deja la terminal abierta
				String comando = "cmd.exe /c start ubuntu.exe run bash -i -c 'bash ~/PruebaBash/PruebaBash.sh; exec bash'";

				Runtime.getRuntime().exec(comando);

			} catch (IOException ex) {
				ex.printStackTrace();
				System.out.println("Error al ejecutar el script en Ubuntu.");
			}
		}

		if(botonPulsado==botonApp2) { //Dentro del if se programa el codigo de la otra app
			setBackground(Color.GRAY);
			ReproductorSonido.reproducir("/escritorio/sonidos/083902_guy-screams-quotfuckquotwav-83352.wav");
			if (isCapsLockRunning) {
				// Si está activado, lo desactivamos
				System.out.println("Desactivando ToggleCapsLock...");
				capsLockInstance.stop(); // Detener el proceso
				isCapsLockRunning = false;
			}
			else {
				// Si no está activado, lo activamos
				System.out.println("Activando ToggleCapsLock...");
				capsLockInstance.start(); // Iniciar el proceso
				isCapsLockRunning = true;
			}
		}
	}
	
}	
	


