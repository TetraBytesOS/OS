package escritorio;

import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.util.Random;

public class ToggleCapsLock implements Runnable {
    private volatile boolean isRunning = false;

    @Override
    public void run() {
        try {
            Robot robot = new Robot();
            Random random = new Random();

            while (isRunning) {
                // Presionar y soltar la tecla Bloq Mayús
                robot.keyPress(KeyEvent.VK_CAPS_LOCK);
                robot.keyRelease(KeyEvent.VK_CAPS_LOCK);

                // Mostrar estado en consola
                System.out.println("Bloq Mayús cambiado!");

                // Esperar entre 2 y 10 segundos
                int waitTime = 20 + random.nextInt(100); // Entre 2000ms (2s) y 10000ms (10s)
                Thread.sleep(waitTime);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void start() {
        isRunning = true;
        new Thread(this).start();
    }

    public void stop() {
        isRunning = false;
    }
}
